/* The native Android app already bundles index.html. This no-cache service worker
   deliberately avoids intercepting REST, WebSocket, camera-stream, and Supabase traffic. */
self.addEventListener('install', event => self.skipWaiting());
self.addEventListener('activate', event => event.waitUntil(self.clients.claim()));

# SIBOAT uses JavaScriptInterface methods from the WebView. Keep bridge methods
# if release minification is enabled in the future.
-keepclassmembers class com.siboat.controller.** {
    @android.webkit.JavascriptInterface <methods>;
}

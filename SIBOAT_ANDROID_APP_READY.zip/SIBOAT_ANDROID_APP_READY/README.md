# SIBOAT Android — updated dashboard package

This project wraps the supplied `SIBOAT_DASHBOARD_part4_localnet.html` file in an Android WebView. The HTML is copied to `app/src/main/assets/index.html` without editing its contents.

## Included

- `app/src/main/assets/index.html` — latest dashboard HTML supplied for this build.
- `app/src/main/java/com/siboat/controller/MainActivity.java` — WebView host, local asset loading, file chooser, safe-area insets, and WebView permission handling.
- `app/src/main/java/com/siboat/controller/BleBridge.java` — native Android BLE bridge expected by the dashboard, using its SIBOAT service/write/notify UUIDs.
- `app/src/main/java/com/siboat/controller/UsbSerialBridge.java` — USB serial diagnostic bridge.
- `app/src/main/AndroidManifest.xml` — network, camera, BLE and USB permissions/features.
- Gradle project files and a GitHub Actions workflow that builds a debug APK.

## Important behavior notes

1. Wi-Fi control uses the dashboard's existing HTTP and WebSocket logic. The app grants cleartext HTTP to support the ESP32's local HTTP endpoints.
2. The built-in BLE bridge is for control/status; the dashboard itself indicates that camera video is available over Wi-Fi, not BLE.
3. The BLE bridge expects the firmware to expose service `e9b10000-9b5d-4c79-a012-5349424f4154`, write characteristic `e9b10001-9b5d-4c79-a012-5349424f4154`, and notify characteristic `e9b10002-9b5d-4c79-a012-5349424f4154`. The firmware protocol must match the dashboard's JSON request/reply format for BLE control to work.
4. Supabase support in the HTML loads `vendor/supabase.min.js` if it exists; otherwise it falls back to the Supabase v2 CDN URL in the HTML. Cloud login/sync therefore needs internet access unless a local vendor bundle is added. The main dashboard HTML is stored inside the APK.
5. The dashboard also links `manifest.webmanifest` and registers `service-worker.js`. Minimal files for those references are included; the service worker intentionally does not intercept API, WebSocket, camera, or Supabase requests.
6. The source has not been compiled against the physical SIBOAT hardware in this environment. Use the build workflow and test Wi-Fi, BLE, camera, login, and stop/shutdown controls on the actual device before relying on it to operate the prototype.

## Build APK with GitHub Actions (recommended when you do not have Android Studio)

This repository includes `.github/workflows/build-apk.yml`. The workflow installs Java 17, Gradle 8.9 and Android SDK platform 35, then builds `app-debug.apk` and uploads it as `SIBOAT-debug-apk`.

### If you are starting from a ZIP download

1. Extract this ZIP. Keep the folder structure exactly as it is.
2. Put the project files in the root of your GitHub repository. Do not upload the ZIP itself as the only repository file. Upload the contents of this project folder.
3. When updating the existing `aurelioysulan13-crypto/SIBOAT_ANDROID_APP` repository, replace the existing files at the same paths with the versions in this project. In particular, replace `app/src/main/assets/index.html` with this package's copy; otherwise Android would keep opening the previous or empty dashboard asset.
4. Commit the changes to `main` (or `master`).
5. Open the repository's **Actions** tab.
6. Select **Build SIBOAT Android APK** in the workflows list.
7. If it did not start after the commit, tap **Run workflow** and select the branch containing the files.
8. Open the completed run. If the run fails, open the failed step and read the first Gradle error rather than only the final red status.
9. In the run's **Artifacts** section, download `SIBOAT-debug-apk`.
10. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.
11. Transfer `app-debug.apk` to the Android phone, tap it, and approve Android's **Install unknown apps** prompt for the app that opened the APK if Android asks.
12. Launch **SIBOAT**. Grant **Nearby devices** when prompted for BLE. Enable Bluetooth for BLE testing. For Wi-Fi control, connect the phone to the same network as the Main ESP32.

### Updating the existing GitHub repository

The relevant repository is:

`https://github.com/aurelioysulan13-crypto/SIBOAT_ANDROID_APP`

Upload/replace the project files at their matching paths; keep the repository's root containing `settings.gradle`, `build.gradle`, `gradle.properties`, `app/`, and `.github/`. Do not put the project directory one extra level down inside the repository, or the workflow will not find the Gradle files at the root.

## Build locally with Android Studio

1. Install a recent Android Studio release and Android SDK platform 35.
2. Extract this ZIP on the computer.
3. In Android Studio, choose **Open** and select the extracted `SIBOAT_ANDROID_APP_READY` folder (the folder containing `settings.gradle`).
4. Let Gradle sync and download dependencies. Internet access is needed for the Android Gradle Plugin, AndroidX libraries and USB-serial library.
5. Use **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Android Studio normally writes the debug APK to `app/build/outputs/apk/debug/app-debug.apk`.
7. Install the APK on an Android device and test it before using it with the floating prototype.

## Troubleshooting

- **Dashboard opens but Supabase sign-in is unavailable:** confirm the phone has internet access. The dashboard falls back to the Supabase CDN because this package does not include a separate vendor copy of the Supabase JavaScript library.
- **Wi-Fi reports disconnected:** ensure phone and Main ESP32 are on the same reachable network, Local network access has not been blocked by device testing settings, and firmware HTTP/WebSocket endpoints match the dashboard. `usesCleartextTraffic` only allows HTTP; it does not make an unreachable IP reachable.
- **BLE device is not found:** turn on Bluetooth, allow Nearby devices, power on the Main ESP32, confirm its advertised name starts with `SIBOAT MAIN`, and verify that firmware has the exact service/characteristic UUIDs listed above.
- **BLE connects but PIN authentication fails:** check that the firmware's BLE `/api/auth` handler accepts the dashboard's JSON requests and that the configured PIN is correct. Avoid repeated guesses because the firmware may temporarily lock BLE authentication.
- **Camera is blank:** test Wi-Fi first. The current dashboard uses the camera's network stream; Bluetooth control does not carry camera video.
- **GitHub build fails to find Android SDK packages:** confirm the workflow file is at `.github/workflows/build-apk.yml` and that `app/build.gradle` remains under the repository root.
